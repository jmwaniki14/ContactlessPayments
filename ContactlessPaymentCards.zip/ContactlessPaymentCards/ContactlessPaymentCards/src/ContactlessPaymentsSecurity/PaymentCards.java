package ContactlessPaymentsSecurity;

import javacard.framework.APDU;
import javacard.framework.Applet;
import javacard.framework.ISO7816;
import javacard.framework.ISOException;
import javacard.framework.Util;

public class PaymentCards extends Applet {
    private static final byte CLA_PAYMENT_TERMINAL = (byte) 0x80;
    private static final byte INS_AUTHENTICATE = (byte) 0x10;

    private SecurityEnhancements securityEnhancements;

    // Constructor should be public
    public PaymentCards() {
        securityEnhancements = new SecurityEnhancements();
    }

    // Correct registration with parameters
    public static void install(final byte[] bArray, final short bOffset, final byte bLength) throws ISOException {
        final PaymentCards applet = new PaymentCards();
        applet.register(bArray, bOffset, bLength);
    }

    public void process(final APDU apdu) throws ISOException {
        if (selectingApplet()) {
            return;
        }

        final byte[] buffer = apdu.getBuffer();
        if (buffer[ISO7816.OFFSET_CLA] != CLA_PAYMENT_TERMINAL) {
            ISOException.throwIt(ISO7816.SW_CLA_NOT_SUPPORTED);
        }

        switch (buffer[ISO7816.OFFSET_INS]) {
            case INS_AUTHENTICATE:
                authenticate(apdu);
                break;
            default:
                ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);
        }
    }

    private void authenticate(final APDU apdu) throws ISOException {
        final byte[] buffer = apdu.getBuffer();
        final short dataLen = apdu.setIncomingAndReceive();

        final short cardNumberLen = buffer[ISO7816.OFFSET_LC];
        final byte[] cardNumber = new byte[cardNumberLen];
        Util.arrayCopyNonAtomic(buffer, ISO7816.OFFSET_CDATA, cardNumber, (short) 0, cardNumberLen);

        final short pinOffset = (short) (ISO7816.OFFSET_CDATA + cardNumberLen);
        final short pinLen = (short) (dataLen - cardNumberLen);
        final byte[] pin = new byte[pinLen];
        Util.arrayCopyNonAtomic(buffer, pinOffset, pin, (short) 0, pinLen);

        // Decrypt card number and PIN
        final byte[] decryptedCardNumber = securityEnhancements.decrypt(cardNumber);
        final byte[] decryptedPin = securityEnhancements.decrypt(pin);

        // Authenticate decrypted card number and PIN
        if (securityEnhancements.verifyPin(decryptedCardNumber, decryptedPin)) {
            buffer[0] = (byte) 0x90; // Success status word
            buffer[1] = (byte) 0x00; // Success status word
        } else {
            buffer[0] = (byte) 0x63; // Warning status word
            buffer[1] = (byte) 0x00; // Warning status word
        }
        apdu.setOutgoingAndSend((short) 0, (short) 2);
    }

    public static byte getClaPaymentTerminal() {
        return CLA_PAYMENT_TERMINAL;
    }

    public static byte getInsAuthenticate() {
        return INS_AUTHENTICATE;
    }

    public SecurityEnhancements getSecurityEnhancements() {
        return securityEnhancements;
    }

    public void setSecurityEnhancements(final SecurityEnhancements securityEnhancements) {
        this.securityEnhancements = securityEnhancements;
    }
}
