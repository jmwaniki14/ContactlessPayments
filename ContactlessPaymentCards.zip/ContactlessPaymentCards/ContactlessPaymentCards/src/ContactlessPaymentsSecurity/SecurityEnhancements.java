package ContactlessPaymentsSecurity;

import javacard.framework.APDU;
import javacard.framework.ISO7816;
import javacard.framework.ISOException;
import javacard.framework.Util;
import javacard.security.AESKey;
import javacard.security.KeyBuilder;
import javacardx.crypto.Cipher;

public class SecurityEnhancements {

    private static final byte[] ENCRYPTION_KEY = new byte[] {
        (byte)0x00, (byte)0x01, (byte)0x02, (byte)0x03,
        (byte)0x04, (byte)0x05, (byte)0x06, (byte)0x07,
        (byte)0x08, (byte)0x09, (byte)0x0A, (byte)0x0B,
        (byte)0x0C, (byte)0x0D, (byte)0x0E, (byte)0x0F
    };

    private Cipher aesCipher;
    private AESKey aesKey;
    private byte[] cardNumbers;
    private byte[] pins;

    public SecurityEnhancements() {
        try {
            aesKey = (AESKey) KeyBuilder.buildKey(KeyBuilder.TYPE_AES, KeyBuilder.LENGTH_AES_128, false);
            aesKey.setKey(ENCRYPTION_KEY, (short) 0);
            aesCipher = Cipher.getInstance(Cipher.ALG_AES_BLOCK_128_ECB_NOPAD, false);
            aesCipher.init(aesKey, Cipher.MODE_ENCRYPT);
        } catch (final Exception e) {
            ISOException.throwIt(ISO7816.SW_UNKNOWN);
        }

        cardNumbers = new byte[] {
            (byte)0x31, (byte)0x32, (byte)0x33, (byte)0x34, (byte)0x35, (byte)0x36, // Card number 123456
            (byte)0x37, (byte)0x38, (byte)0x39, (byte)0x30, (byte)0x31, (byte)0x32  // Card number 789012
        };
        pins = new byte[] {
             (byte)0x31, (byte)0x32, (byte)0x33, (byte)0x34, // PIN 1234
             (byte)0x35, (byte)0x36, (byte)0x37, (byte)0x38  // PIN 5678
       };

    }

    public void process(final APDU apdu) {
        final byte[] buffer = apdu.getBuffer();
        final byte cmd = buffer[ISO7816.OFFSET_INS];

        switch (cmd) {
            case (byte) 0xB2:
                handleEncryption(apdu);
                break;
            case (byte) 0xB1:
                handlePinVerification(apdu);
                break;
            default:
                ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);
        }
    }

    private void handleEncryption(final APDU apdu) {
        final byte[] buffer = apdu.getBuffer();
        final short lc = (short) (buffer[ISO7816.OFFSET_LC] & 0xFF);
        final byte[] dataToEncrypt = new byte[lc];
        Util.arrayCopy(buffer, ISO7816.OFFSET_CDATA, dataToEncrypt, (short) 0, lc);

        final byte[] encryptedData = encrypt(dataToEncrypt);

        apdu.setOutgoing();
        apdu.setOutgoingLength((short) encryptedData.length);
        apdu.sendBytesLong(encryptedData, (short) 0, (short) encryptedData.length);
    }

   private void handlePinVerification(final APDU apdu) {
       final byte[] buffer = apdu.getBuffer();
       final short lc = (short) (buffer[ISO7816.OFFSET_LC] & 0xFF);
       final byte[] cardNumber = new byte[6];
       final byte[] pin = new byte[4]; // 4 bytes for the PIN

    Util.arrayCopy(buffer, ISO7816.OFFSET_CDATA, cardNumber, (short) 0, (short) 6);
    Util.arrayCopy(buffer, (short) (ISO7816.OFFSET_CDATA + 6), pin, (short) 0, (short) 4); // 4 bytes for the PIN

    final boolean isValid = verifyPin(cardNumber, pin);
    if (isValid) {
        byte[] successMessage = new byte[] {
            (byte)'P', (byte)'I', (byte)'N', (byte)' ', (byte)'V', (byte)'E', (byte)'R', (byte)'I', (byte)'F', (byte)'I', (byte)'E', (byte)'D', 
            (byte)' ', (byte)'S', (byte)'U', (byte)'C', (byte)'C', (byte)'E', (byte)'S', (byte)'S', (byte)'F', (byte)'U', (byte)'L', (byte)'L', 
            (byte)'Y', (byte)'!', (byte)' ', (byte)'T', (byte)'R', (byte)'A', (byte)'N', (byte)'S', (byte)'A', (byte)'C', (byte)'T', (byte)'I', 
            (byte)'O', (byte)'N', (byte)' ', (byte)'H', (byte)'A', (byte)'S', (byte)' ', (byte)'B', (byte)'E', (byte)'E', (byte)'N', (byte)' ', 
            (byte)'C', (byte)'O', (byte)'M', (byte)'P', (byte)'L', (byte)'E', (byte)'T', (byte)'E', (byte)'D', (byte)'.'
        };
        sendResponse(apdu, (short) 0x9000, successMessage);
    } else {
        byte[] failureMessage = new byte[] {
            (byte)'I', (byte)'N', (byte)'V', (byte)'A', (byte)'L', (byte)'I', (byte)'D', (byte)' ', (byte)'P', (byte)'I', (byte)'N', (byte)' ', 
            (byte)'O', (byte)'R', (byte)' ', (byte)'C', (byte)'A', (byte)'R', (byte)'D', (byte)' ', (byte)'N', (byte)'U', (byte)'M', (byte)'B', 
            (byte)'E', (byte)'R', (byte)'!', (byte)' ', (byte)'T', (byte)'R', (byte)'A', (byte)'N', (byte)'S', (byte)'A', (byte)'C', (byte)'T', 
            (byte)'I', (byte)'O', (byte)'N', (byte)' ', (byte)'D', (byte)'E', (byte)'C', (byte)'L', (byte)'I', (byte)'N', (byte)'E', (byte)'D', 
            (byte)'!'
        };
        sendResponse(apdu, (short) 0x6300, failureMessage);
        }
    }

    private void sendResponse(final APDU apdu, final short status, final byte[] message) {
        final short responseLength = (short) message.length;

        apdu.setOutgoing();
        apdu.setOutgoingLength(responseLength);
        apdu.sendBytesLong(message, (short) 0, responseLength);
    }

    public byte[] encrypt(final byte[] input) {
        final byte[] output = new byte[input.length];
        try {
            aesCipher.doFinal(input, (short)0, (short)input.length, output, (short)0);
        } catch (final Exception e) {
            ISOException.throwIt(ISO7816.SW_UNKNOWN);
        }
        return output;
    }

    public byte[] decrypt(final byte[] input) {
        final byte[] output = new byte[input.length];
        try {
            aesCipher.init(aesKey, Cipher.MODE_DECRYPT);
            aesCipher.doFinal(input, (short)0, (short)input.length, output, (short)0);
        } catch (final Exception e) {
            ISOException.throwIt(ISO7816.SW_UNKNOWN);
        }
        return output;
    }

    public boolean verifyPin(final byte[] cardNumber, final byte[] pin) {
         final short numCards = 2; //Number of cands 
         final short cardNumberLen = 6; // 6 bytes for the CardNumber
         final short pinLen = 4; // 4 bytes for the PIN

    for (short i = 0; i < numCards; i++) {
        final byte[] storedCardNumber = new byte[cardNumberLen];
        Util.arrayCopy(cardNumbers, (short)(i * cardNumberLen), storedCardNumber, (short)0, cardNumberLen);

        if (Util.arrayCompare(storedCardNumber, (short)0, cardNumber, (short)0, cardNumberLen) == 0) {
            final byte[] storedPin = new byte[pinLen];
            Util.arrayCopy(pins, (short)(i * pinLen), storedPin, (short)0, pinLen);
            return Util.arrayCompare(storedPin, (short)0, pin, (short)0, pinLen) == 0;
        }
    }
    return false;
}

}
