package ContactlessPaymentsSecurity ;

import javacard.framework.*;

public class ContactlessPaymentsSecurity extends Applet
{
private static final byte CLA_CONTACTLESS = (byte) 0x80;
    private static final byte INS_AUTHENTICATE = (byte) 0x10;
    private static final byte[] AUTHORIZED_PIN = new byte[] { (byte)0x12, (byte)0x34 };

    // The install method is used to create and register the applet
    public static void install(byte[] bArray, short bOffset, byte bLength) {
        new ContactlessPaymentsSecurity().register(bArray, (short) (bOffset + 1), bArray[bOffset]);
    }

    // The process method handles APDU commands
    public void process(APDU apdu) throws ISOException {
        if (selectingApplet()) {
            return;
        }

        byte[] buf = apdu.getBuffer();
        if (buf[ISO7816.OFFSET_CLA] != CLA_CONTACTLESS) {
            ISOException.throwIt(ISO7816.SW_CLA_NOT_SUPPORTED);
        }

        switch (buf[ISO7816.OFFSET_INS]) {
            case INS_AUTHENTICATE:
                processAuthentication(apdu);
                break;
            default:
                ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);
        }
    }

    // Process the authentication command
    private void processAuthentication(APDU apdu) throws ISOException {
        byte[] buffer = apdu.getBuffer();
        short dataLen = apdu.setIncomingAndReceive();

        if (dataLen != AUTHORIZED_PIN.length) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        byte[] receivedPin = new byte[dataLen];
        Util.arrayCopy(buffer, ISO7816.OFFSET_CDATA, receivedPin, (short) 0, dataLen);

        if (Util.arrayCompare(receivedPin, (short) 0, AUTHORIZED_PIN, (short) 0, (short) AUTHORIZED_PIN.length) == 0)
           {
            buffer[0] = (byte) 0x90; // Success status word
            buffer[1] = (byte) 0x00; // Success status word
        } else {
            buffer[0] = (byte) 0x63; // Warning status word
            buffer[1] = (byte) 0x00; // Warning status word
        }
        apdu.setOutgoingAndSend((short) 0, (short) 2);
    }
}
